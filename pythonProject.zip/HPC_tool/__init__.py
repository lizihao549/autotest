import os
import paramiko
import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog


class TestApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("测试应用程序")

        self.start_button = tk.Button(root, text="开始测试", command=self.start_test)
        self.start_button.pack(pady=10)

        self.test_project_label = tk.Label(root, text="选择测试项目:")
        self.test_project_label.pack(pady=5)

        self.test_project_var = tk.StringVar()
        self.test_project_dropdown = tk.OptionMenu(root, self.test_project_var, *self.get_test_projects())
        self.test_project_dropdown.pack(pady=5)

        self.config_file_path = None

    def get_test_projects(self):
        # 选择项目文件夹
        project_folder = filedialog.askdirectory(title="选择项目文件夹")
        if not project_folder:
            return []

            # 获取HPC_tool_file文件夹中的所有文件夹名
        hpc_tool_folder = os.path.join(project_folder, "HPC_tool_file")
        if not os.path.exists(hpc_tool_folder):
            messagebox.showerror("错误", "HPC_tool_file文件夹不存在")
            return []

        return [folder for folder in os.listdir(hpc_tool_folder) if
                os.path.isdir(os.path.join(hpc_tool_folder, folder))]

    def start_test(self):
        test_project = self.test_project_var.get()
        if not test_project:
            messagebox.showwarning("警告", "请选择一个测试项目")
            return

        project_folder = filedialog.askdirectory(title="选择配置文件夹")
        if not project_folder:
            return

        self.config_file_path = os.path.join(project_folder, "config.txt")

        if not os.path.isfile(self.config_file_path):
            messagebox.showerror("错误", "配置文件不存在")
            return

        self.connect_to_hosts()

    def connect_to_hosts(self):
        # 从config.txt读取IP和用户名密码
        try:
            with open(self.config_file_path, 'r') as f:
                config = f.readlines()

            hosts = {}
            for line in config:
                if line.startswith("host_"):
                    parts = line.strip().split(":")
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip()
                        hosts[key] = value

            if len(hosts) == 0:
                messagebox.showerror("错误", "没有找到有效的主机配置")
                return

                # 连接到每个主机
            for host_key, ip in hosts.items():
                username = "your_username"  # TODO: 根据需求动态获取
                password = "your_password"  # TODO: 根据需求动态获取
                self.ssh_connect(ip, username, password)

            messagebox.showinfo("成功", "连接完成！")

        except Exception as e:
            messagebox.showerror("错误", str(e))

    def ssh_connect(self, ip, username, password):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, password=password)
            # 这里可以执行其他命令
            ssh.close()
        except Exception as e:
            messagebox.showerror("SSH连接错误", f"无法连接到 {ip}: {str(e)}")


if __name__ == '__main__':
    root = tk.Tk()
    app = TestApplication(root)
    root.mainloop()